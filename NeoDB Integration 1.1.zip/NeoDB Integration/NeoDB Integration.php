<?php
/*
Plugin Name: NeoDB Integration
Description: Integrates NeoDB records into WordPress using a shortcode.
Version: 1.0
Author: anotherdayu.com
*/

// Register a settings page
function neodb_add_settings_page() {
    add_options_page(
        'NeoDB Settings',
        'NeoDB Settings',
        'manage_options',
        'neodb-settings',
        'neodb_render_settings_page'
    );
}
add_action('admin_menu', 'neodb_add_settings_page');

// Render the settings page
function neodb_render_settings_page() {
    ?>
    <div class="wrap">
        <h1>NeoDB Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('neodb_settings');
            do_settings_sections('neodb-settings');
            submit_button();
            ?>
        </form>
        <form method="post">
            <?php wp_nonce_field('neodb_manual_update_action', 'neodb_manual_update_nonce'); ?>
            <input type="submit" name="neodb_manual_update" class="button button-primary" value="手动更新数据">
        </form>
        <?php
        if (isset($_POST['neodb_manual_update'])) {
            if (check_admin_referer('neodb_manual_update_action', 'neodb_manual_update_nonce')) {
                neodb_manual_update();
                echo '<div class="updated"><p>数据已更新。</p></div>';
            } else {
                echo '<div class="error"><p>Nonce 验证失败，无法更新数据。</p></div>';
            }
        }
        ?>
    </div>
    <?php
}

// Register settings
function neodb_register_settings() {
    register_setting('neodb_settings', 'neodb_token');

    add_settings_section(
        'neodb_settings_section',
        'NeoDB API Settings',
        null,
        'neodb-settings'
    );

    add_settings_field(
        'neodb_token',
        'NeoDB Bearer Token',
        'neodb_token_field_callback',
        'neodb-settings',
        'neodb_settings_section'
    );
}
add_action('admin_init', 'neodb_register_settings');

// Callback function for the token input field
function neodb_token_field_callback() {
    $token = get_option('neodb_token');
    echo '<input type="text" id="neodb_token" name="neodb_token" value="' . esc_attr($token) . '" size="50" />';
}

// Manual update function
function neodb_manual_update() {
    // Example: Fetch and store data in a transient or option
    $categories = ['book', 'movie']; // Add more categories as needed
    $type = 'complete'; // Example type
    foreach ($categories as $category) {
        $data = fetch_neodb_data($category, $type);
        if ($data) {
            set_transient('neodb_' . $category . '_' . $type, $data, HOUR_IN_SECONDS);
        }
    }
}

// Fetch NeoDB data
function fetch_neodb_data($category, $type) {
    $token = get_option('neodb_token');
    if (!$token) {
        return null;
    }

    $url = sprintf('https://neodb.social/api/me/shelf/%s?category=%s&page=1', $type, $category);

    $response = wp_remote_get($url, array(
        'headers' => array(
            'Accept' => 'application/json',
            'Authorization' => 'Bearer ' . $token
        )
    ));

    if (is_wp_error($response)) {
        return null;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        return null;
    }

    return $data;
}

// Shortcode function
function neodb_shortcode($atts) {
    $atts = shortcode_atts(
        array(
            'category' => 'book',
            'type' => 'complete',
        ),
        $atts,
        'neodb'
    );

    $category = $atts['category'];
    $type = $atts['type'];

    // Retrieve data from transient
    $data = get_transient('neodb_' . $category . '_' . $type);
    if (!$data) {
        $data = fetch_neodb_data($category, $type);
        if ($data) {
            set_transient('neodb_' . $category . '_' . $type, $data, HOUR_IN_SECONDS);
        }
    }

    if (empty($data['data'])) {
        return '没有找到相关数据';
    }

    ob_start();
    ?>
    <div class="item-gallery">
        <?php foreach (array_slice($data['data'], 0, 10) as $value): ?>
            <?php $item = $value['item']; ?>
            <div class="item-card">
                <a class="item-card-upper" href="<?php echo esc_url($item['id']); ?>" target="_blank" rel="noreferrer">
                    <img class="item-cover" src="<?php echo esc_url($item['cover_image_url']); ?>" alt="<?php echo esc_attr($item['display_title']); ?>">
                </a>
                <div class="rate">
                    <?php if (!empty($item['rating'])): ?>
                        <span><b><?php echo esc_html($item['rating']); ?></b>🌟</span>
                        <br>
                        <span class="rating-count"><?php echo esc_html($item['rating_count']); ?>人评分</span>
                    <?php else: ?>
                        <span>暂无🌟</span>
                        <br>
                        <span class="rating-count"><?php echo esc_html($item['rating_count']); ?>人评分</span>
                    <?php endif; ?>
                </div>
                <h3 class="item-title"><?php echo esc_html($item['display_title']); ?></h3>
            </div>
        <?php endforeach; ?>
    </div>
    <style>
        .item-gallery {
            display: flex;
            padding: 0 1rem;
            overflow-x: scroll;
            align-items: baseline;
        }
        .item-card {
            display: flex;
            flex-direction: column;
            flex: 0 0 17%;
            margin: 0 0.5rem 1rem;
            border-radius: 5px;
            transition: transform 0.2s;
            width: 8rem;
        }
        .item-card:hover {
            transform: translateY(-5px);
        }
        .rate {
            text-align: center;
        }
        .rating-count {
            font-size: 0.8rem;
            color: grey;
        }
        .item-cover {
            width: 100%;
            min-height: 3rem;
            border: 2px solid transparent;
        }
    </style>
    <?php
    return ob_get_clean();
}
add_shortcode('neodb', 'neodb_shortcode');
